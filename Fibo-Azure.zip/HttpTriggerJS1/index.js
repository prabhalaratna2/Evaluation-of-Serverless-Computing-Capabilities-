module.exports = function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');
	
	if (req.query.number || (req.body && req.body.number)) {

        var bignumber = require('bignumber.js')   
		var random = require('random-number') 
		random = req.query.random
		var InputNumber = (req.query.number || req.body.number)
       var inputBigNumber = new bignumber(InputNumber);
	   if(random == "Y")
	   {
	   if (InputNumber >=1 && InputNumber <= 100)
	   {
		//var inputBigNumber = 1 + random(0,1)*100;
		var inputBigNumber = randomnIntFromInterval(1,100);
		context.log(inputBigNumber);
	   };

	    if (InputNumber >= 101 && InputNumber <=1000)
	   {
		//var inputBigNumber = 101 + random(0,1)*1000;
		var inputBigNumber = randomnIntFromInterval(101,1000);
		context.log(inputBigNumber);
		
	   };
	   if (InputNumber >=1001 && InputNumber <= 50000)
	   {
		   //var inputBigNumber = 1001 + random(0,1)*50000;
		   var inputBigNumber = randomnIntFromInterval(1001,50000);
		   context.log(inputBigNumber);
	   };
	   if (InputNumber >= 50001 && InputNumber <= 100000)
	   {
		  // var inputBugnumber = 50001 + random(0,1)*100000;
		   var inputBigNumber = randomnIntFromInterval(50001,100000);
		   context.log(inputBigNumber);
	   };
	   var result = fibonacci(inputBigNumber, bignumber);
	   };
	   if (random ='N')
	   {
		var result = fibonacci(inputBigNumber, bignumber);
	   };
	   //var result = fibonacci(inputBigNumber, bignumber);
		 context.log('Fibonacci output number:' + result.toString())
		 context.res = {

				body:"Fibonacci output : " + result.toString() 			};
			if (InputNumber <= 0)
			{
			 context.res = {
				body: "Enter Valid number"
			};	
			};
		}
	
				else {
			context.res = {
				status: 400,
				body: "Please pass a number on the query string or in the request body"
			};
		}
		context.done();
};
function fibonacci(num, bignumber){

  var a = new bignumber(1);         // "11"
  var b = new bignumber(0);
  var temp = new bignumber(a);

  while (num >= 0){
    temp = a;
    a = a.plus(b);
    b = temp;
    num--;
  }

  return b.toString();
}
function randomnIntFromInterval(min,max)
{
	return Math.floor(Math.random()*(max-min+1)+min);
}